package statesEncapsulation10_vice;

public class SalesReport {
    private int totalCoins;
    private int totalGumballsDispensed;
    private int totalToysDispensed;
    private int remainingGumballs;
    private int remainingToys;

    // Конструктор и другие методы для обновления и получения данных
    // ...
}
